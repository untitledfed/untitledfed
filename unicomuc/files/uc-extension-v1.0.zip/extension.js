const vscode = require('vscode');

function activate(context) {
  const keywords = [
    "open", "closed","@create", "@override", "@crash", "@exit", "@sleep", "@on", "@use", "@continue", "@at", "@noWait", "@cast", "@recieve", "console", "##",
    "function", "class", "base",
    "if", "else", "repeat", "library", "try", "error",
    "until", "int", "double", "boolean", "for", "forever", "string", "void", "Window", "Display", "property", "const",
    "log", "keyPressed", "type", "SCREENWIDTH", "SCREENHEIGHT", "x", "y", "width", "height", "name", "id", "color"
  ];

  const provider = vscode.languages.registerCompletionItemProvider(
    'uc',
    {
      provideCompletionItems(document, position) {
        return keywords.map(keyword =>
          new vscode.CompletionItem(keyword, vscode.CompletionItemKind.Keyword)
        );
      }
    }
  );

  context.subscriptions.push(provider);
}

exports.activate = activate;
function deactivate() {}
module.exports = { activate, deactivate };